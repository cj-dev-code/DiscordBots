# -*- coding: utf-8 -*-
"""
Created on Sat Sep  5 14:28:16 2020

@author: josep
"""

# Commands ECStudents and ECFaculty may use.

# Commands that Admin may use.
